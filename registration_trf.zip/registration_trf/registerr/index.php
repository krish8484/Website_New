
<?php
/*things to do
*/  //header('Cache-Control: no cache'); //no cache
//session_cache_limiter('private_no_expire'); // works
//session_cache_limiter('public'); // works too
session_start();
  include("headproj.php");
  require('../cms1/includes/db.php'); 
  //session_start();
?>
<?
if(isset($_POST['register']))
{
  $name = mysqli_real_escape_string($con, $_POST['name']);
  $email    = mysqli_real_escape_string($con, $_POST['your_email']);
  $contact    = mysqli_real_escape_string($con, $_POST['contact']);
  $branch = mysqli_real_escape_string($con, $_POST['inputBranch']);
  $year = mysqli_real_escape_string($con, $_POST['year']);
  $domain= mysqli_real_escape_string($con, $_POST['inputDomain']);
  $ans1 = mysqli_real_escape_string($con, $_POST['ans1']);
  $ans2 = mysqli_real_escape_string($con, $_POST['ans2']);
  $ans3 = mysqli_real_escape_string($con, $_POST['ans3']);
  $ans4 = mysqli_real_escape_string($con, $_POST['ans4']);
  $ans5 = mysqli_real_escape_string($con, $_POST['ans5']);
  $id = mysqli_real_escape_string($con, $_POST['grNo']);
  
   

  $password = password_hash( $password, PASSWORD_BCRYPT, array('cost' => 12));


  $query="INSERT INTO `level2`(`GRNO`, `Name`, `Email`, `Number`, `Branch`, `Year`, `Domain`, `ans1`, `ans2`, `ans3`, `ans4`, `ans5`) VALUES ('$id','$name','$email','$contact','$branch','$year','$domain','$ans1','$ans2','$ans3','$ans4','$ans5')";
  $run = mysqli_query($con, $query) or trigger_error("Query Failed! SQL: $query - Error: ".mysqli_error($con), E_USER_ERROR);
  
    
  
        
    

}
 ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Registration form</title>
    <!-- Mobile Specific Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="keywords" content="">
    <meta name="description" content="">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <!-- Font-->
    <link rel="stylesheet" type="text/css" href="css/opensans-font.css">
    <link rel="stylesheet" type="text/css" href="fonts/line-awesome/css/line-awesome.min.css">
    <!-- Jquery -->
    <link rel="stylesheet" href="https://jqueryvalidation.org/files/demo/site-demos.css">
    <!-- Main Style Css -->
    <link rel="stylesheet" href="css/style.css" />
</head>

<body class="form-v4">
    <div class="page-content">
        <div class="form-v4-content" style="margin-top: 12% !important; margin-bottom: 12% !important;">
            <div class="form-left">
                <h2>Robodriod</h2>
                <p class="text-1">Technical teams build you to apply your theoretical knowledge in real life situations while striving for precision under immense pressure during competitions. If you are not just running after knowledge but, wish to acquire wisdom, you are at the right place!</p>
            </div>
            <form class="form-detail" action="#" method="post" id="myform">
                <h2>REGISTER FORM</h2>
                <div class="form-row">
                    <label for="first_name">Name</label>
                    <input type="text" name="name" id="name" class="input-text" required>
                </div>
                <div class="form-group">
                    <div class="form-row form-row-1">
                        <label for="grNo">Gr. No.</label>
                        <input type="text" name="grNo" id="grNo" class="input-text" required>
                    </div>
                    <div class="form-row form-row-1 ">
                        <label for="contact">Contact Number</label>
                        <input type="text" name="contact" id="contact" class="input-text" required>
                    </div>
                </div>
                <div class="form-row">
                    <label for="your_email">Your Email</label>
                    <input type="email" name="your_email" id="your_email" class="input-text" required pattern="">
                </div>


                <div class="form-group" style="padding-bottom: 8%; ">
                    <div class="form-row form-row-1">
                        <label for="inputBranch">Branch</label>
                        <select id="inputBranch" name="inputBranch" class="form-control" style="padding-left: 0; padding-right: 0;" title="select your branch" required>
                            <option hidden selected>Select</option>
                            <option>Computer</option>
                            <option>E&TC</option>
                            <option>Mechanical</option>
                            <option>Electronics</option>
                            <option>IT</option>
                            <option>Instrumentation</option>
                            <option>Indus Prod</option>
                            <option>Chemical</option>
                        </select>
                    </div>
                    <div class="form-row form-row-1">
                        <label for="inputBranch">Year</label>
                        <select id="inputBranch" name="inputBranch" class="form-control" style="padding-left: 0; padding-right: 0;" title="select your branch" required>
                            <option hidden selected>Select</option>
                            <option>FY</option>
                            <option>SY</option>
                        </select>
                    </div>
                     <div class="form-row form-row-1">
                        <label for="inputDomain">Domain</label>
                        <select id="inputDomain" name="inputDomain" class="form-control" style="padding-left: 0; padding-right: 0;" title="select your branch" required>
                            <option hidden selected>Select</option>
                            <option>Electronics</option>
                            <option>Mechanical</option>
                            <option>Programming</option>
                            <option>Administration</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-row">
                    <label for="ans1">Why do you want to be a part of TRF?</label>
                    <textarea class="form-control input-text" id="ans1" name="ans1" rows="3" required></textarea>
                </div>
                
                <div class="form-row">
                    <label for="ans2">What Technical/Managerial skills do you possess?</label>
                    <textarea class="form-control input-text" id="ans2" name="ans2" rows="3" required></textarea>
                </div>
                
                <div class="form-row">
                    <label for="ans3">Do you have any competitive/industrial internship experience? If yes, describe in brief.</label>
                    <textarea class="form-control input-text" id="ans3" name="ans3" rows="3" required></textarea>
                </div>
                <div class="form-row">
                    <label for="ans4">What was your EDI project? Explain in short.</label>
                    <textarea class="form-control input-text" id="ans4" name="ans4" rows="3" required></textarea>
                </div>
                <div class="form-row">
                    <label for="ans5">What are your expectations from the club?</label>
                    <textarea class="form-control input-text" id="ans5" name="ans5" rows="3" required></textarea>
                </div>

               
                <div class="form-row-last">
                    <input type="submit" name="register" class="register" value="Register">
                </div>
            </form>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
    <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>

</body>

</html>

<style>
        
/*FOOTER*/
          

footer {
  background: #16222A;
  background: -webkit-linear-gradient(59deg, #3A6073, #16222A);
  background: linear-gradient(59deg, #3A6073, #16222A);
  color: white;
  margin-top:100px;
}

footer a {
  color: #fff;
  font-size: 14px;
  transition-duration: 0.2s;
}

footer a:hover {
  color: #FA944B;
  text-decoration: none;
}

.copy {
  font-size: 12px;
  padding: 10px;
  border-top: 1px solid #FFFFFF;
}

.footer-middle {
  padding-top: 2em;
  color: white;
}


/*SOCİAL İCONS*/

/* footer social icons */

ul.social-network {
  list-style: none;
  display: inline;
  margin-left: 0 !important;
  padding: 0;
}

ul.social-network li {
  display: inline;
  margin: 0 5px;
}


/* footer social icons */

.social-network a.icoFacebook:hover {
  background-color: #3B5998;
}

.social-network a.icoLinkedin:hover {
  background-color: #007bb7;
}
.social-network a.icoInstagram:hover {
  background: #833ab4;  /* fallback for old browsers */
background: -webkit-linear-gradient(to right, #fcb045, #fd1d1d, #833ab4);  /* Chrome 10-25, Safari 5.1-6 */
background: linear-gradient(to right, #fcb045, #fd1d1d, #833ab4); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */

}

.social-network a.icoFacebook:hover i,
.social-network a.icoInstagram:hover i,
.social-network a.icoLinkedin:hover i {
  color: #fff;
}

.social-network a.socialIcon:hover,
.socialHoverClass {
  color: #44BCDD;
}

.social-circle li a {
  display: inline-block;
  position: relative;
  margin: 0 auto 0 auto;
  -moz-border-radius: 50%;
  -webkit-border-radius: 50%;
  border-radius: 50%;
  text-align: center;
  width: 30px;
  height: 30px;
  font-size: 15px;
}

.social-circle li i {
  margin: 0;
  line-height: 30px;
  text-align: center;
}

.social-circle li a:hover i,
.triggeredHover {
  -moz-transform: rotate(360deg);
  -webkit-transform: rotate(360deg);
  -ms--transform: rotate(360deg);
  transform: rotate(360deg);
  -webkit-transition: all 0.2s;
  -moz-transition: all 0.2s;
  -o-transition: all 0.2s;
  -ms-transition: all 0.2s;
  transition: all 0.2s;
}

.social-circle i {
  color: #595959;
  -webkit-transition: all 0.8s;
  -moz-transition: all 0.8s;
  -o-transition: all 0.8s;
  -ms-transition: all 0.8s;
  transition: all 0.8s;
}

.social-network a {
  background-color: #F9F9F9;
}
  #ftr {
          list-style: none;
          padding: 0;
        }
        .ftrl {
          padding-left: 1.3em;
        }
        #ftren:before {
          content: "\f0e0"; 
          font-family: FontAwesome;
          display: inline-block;
          margin-left: -1.3em; 
          width: 1.3em; 
            transform: translateY(25px);
        }
            #ftrph:before {
          content: "\f095"; 
          font-family: FontAwesome;
          display: inline-block;
          margin-left: -1.3em; 
          width: 1.3em; 
        }
            #ftrad:before {
          content: "\f015"; 
          font-family: FontAwesome;
          display: inline-block;
          margin-left: -1.3em; 
          width: 1.3em; 
        }
          
    </style>
<footer class="mainfooter" role="contentinfo" style="margin-top: 6%;">
    <div class="footer-middle">
      <div class="container">
        <div class="row">
          <div class="col-md-3"></div>
          <div class="col-md-3 col-sm-6">
            <!--Column1-->
            <div class="footer-pad">
              <h4 style="color: white;">The Robotics Forum </h4>
              <ul class="list-unstyled " id="ftr">
               <li class="ftrl" id="ftrad"><span>VIT college, Upper Indiranagar, <br></span><span>Bibwewadi, </span>Pune-411037 </li>
            <li class="ftrl" id="ftrph">(+91)7020787632</li>
            <li class="ftrl" id="ftren" style="transform: translateY(-25px); word-wrap: break-word;">theroboticsforumvitpune@gmail.com</li>
              </ul>
            </div>
          </div>
          <div class="col-md-3">
            <h4 style="color: white;">Follow Us</h4>
            <ul class="social-network social-circle">
              <li><a href="http://facebook.com/theroboticsforum" class="icoFacebook" title="Facebook"><i class="fa fa-facebook"></i></a></li>
              <li><a href="http://instagram.com/vitpunerobotics" class="icoInstagram" title="Instagram"><i class="fa fa-instagram"></i></a></li>
              <li><a href="https://www.linkedin.com/company/the-robotics-forum/" class="icoLinkedin" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
            </ul>
          </div>
          <div class="col-md-3"></div>
        </div>
        <div class="row">
          <div class="col-md-12 copy">
            <p class="text-center">&copy; Copyright 2019 - The Robotics Forum. All rights reserved.</p>
          </div>
        </div>

      </div>
    </div>
  </footer>
    </body>
</html>
  <script>
      
      var shtp = document.getElementsByClassName('descrp')
          for( var i=0; i< shtp.length;i++){
              shtp[i].innerHTML = shtp[i].innerHTML.substring(0,200) + "....";
          }
      
// If user clicks anywhere outside of the modal, Modal will close

var modal = document.getElementById('modal-wrapper');
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>
